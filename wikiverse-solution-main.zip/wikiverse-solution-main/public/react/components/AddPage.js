import React, {useState} from 'react';
import apiURL from '../api';

export const AddPage = ({setIsAddingPage, setPages, pages}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [authorEmail, setAuthorEmail] = useState('');
  const [tags, setTags] = useState('');

  const handleSubmit = async ev => {
    try {
      ev.preventDefault();
      const response = await fetch(`${apiURL}/wiki`, {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title,
          content,
          name: authorName,
          email: authorEmail,
          tags,
        })
      });
      const data = await response.json();
      if(data) {
        setPages([...pages, data]);
        setIsAddingPage(false);
      }
      
    } catch (error) {
      console.error(error);
    }
  }

  return <>
    <form onSubmit={handleSubmit}>
      <h2>Add a Page</h2>
      <div><input type="text" placeholder="Title" value={title} onChange={ev => setTitle(ev.target.value)}/></div>
      <div><input type="text" placeholder="Article Content" value={content} onChange={ev => setContent(ev.target.value)}/></div>
      <div><input type="text" placeholder="Author Name" value={authorName} onChange={ev => setAuthorName(ev.target.value)}/></div>
      <div><input type="text" placeholder="Author Email" value={authorEmail} onChange={ev => setAuthorEmail(ev.target.value)}/></div>
      <div><input type="text" placeholder="Tags" value={tags} onChange={ev => setTags(ev.target.value)}/></div>
      <button type="submit">Create Page</button>
    </form>
    <button onClick={() => setIsAddingPage(false)}>cancel</button>
  </>
} 
	